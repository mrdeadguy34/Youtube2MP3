#ifndef BASEWINDOW_H
#define BASEWINDOW_H

#include "datalabel.h"
#include "json.hpp"
#include <QtCore>
#include <QtWidgets>
#include <QApplication>
//#include <string>

class Downloads : public QObject
{
    Q_OBJECT

public:
    Downloads(QVector<DataWidget*> Files, std::string Directory);
    void DownloadFiles();

private:
    QVector<DataWidget*> DLFiles;
    std::string directory;

signals:
    void finished();
};

class BaseWindow : public QWidget
{

    Q_OBJECT

public:
    BaseWindow(QWidget *parent = 0);
    QString Directory = qApp->applicationDirPath(); //Main app directory
    QMenuBar *WindowMenu;
    QMenu *MainMenu;
    QAction *InputUrl;
    QAction* DownloadAction;
    QAction* QuitAction;
    ~BaseWindow();

private:
    void CreateActions();
    void LoadWidgets();
    void createNewData(QString Url, std::string hashString);
    void ShowCurrent(QString ID);
    QDialog *UrlBox;
    QLineEdit *UrlInput;
    QVector<DataWidget*> DataWidgets; //Vector containing the data widgets

public slots:
    void GetUrl();
    void SubmitUrl();
    void DeleteData(QString ID);
    void ShowNext(QString ID);
    void DownloadMP3();
    void CleanUpAll();
};


//Utility functions (definitely not taken from stack overflow at all)
QString getLength(std::string ISOString);
void execCmd(const char* command);
bool dirExists(const std::string& dirName_in);
void SetSize(QWidget* window, int x,int y);

#endif // BASEWINDOW_H
