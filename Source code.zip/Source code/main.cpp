#include "basewindow.h"
#include "json.hpp"
#include <QtCore>
#include <QtWidgets>
#include <QApplication>
#include <Windows.h>

QString getLength(std::string ISOString)
{
    //Get the QString in format "(m):(s)" from ISO 8601 duration string. Does not accept hours
    QString ISOQString = QString::fromStdString(ISOString);
    ISOQString.remove("PT").remove("S");
    QStringList Times = ISOQString.split("M");
    QString Minutes = Times.value(0);
    QString Seconds = Times.value(1);
    if (Seconds.toInt() < 10){
        Seconds = "0"+Seconds;
    }
    QString formatTime = Minutes + ":" + Seconds;
    return formatTime;
}

void execCmd(const char* command)
{
    //Command to open up cmd without causing a window pop up
    //Used to run python commands and youtube-dl
    wchar_t *path = (wchar_t*) malloc(sizeof(wchar_t) * 500);
    for (int i = 0; i < strlen(command) + 1; i++)
    {
        path[i] = command[i];
    }

    PROCESS_INFORMATION pi;
    STARTUPINFO si;

    ZeroMemory(&si, sizeof(si));
    si.cb = sizeof(si);
    ZeroMemory(&pi, sizeof(pi));

    if (!CreateProcess(NULL,
        path,
        NULL,
        NULL,
        FALSE,
        CREATE_NO_WINDOW,
        NULL,
        NULL,
        &si,
        &pi))
    {
        qDebug() << "Could not start command "<< QString::fromLocal8Bit(command) << GetLastError();
        return;
    }
    WaitForSingleObject(pi.hProcess, INFINITE);

    CloseHandle(pi.hProcess);
    CloseHandle(pi.hThread);
}

bool dirExists(const std::string& dirName_in)
{
  //Check if the directory has been made by the JSON download
  //Thus checks vailidity of URL
  DWORD ftyp = GetFileAttributesA(dirName_in.c_str());
  if (ftyp == INVALID_FILE_ATTRIBUTES)
    return false;  //Path error

  if (ftyp & FILE_ATTRIBUTE_DIRECTORY)
    return true;   //Directory exists

  return false;    //Directory not found
}

void SetSize(QWidget *window, int x,int y)
{
    //Force QWidget size
    window->resize(x,y);
    window->setMaximumSize(x,y);
    window->setMinimumSize(x,y);
}

int main(int argc, char *argv[])
{
    //Create internet check here
    QApplication app(argc, argv);
    QApplication::setApplicationName("Youtube2MP3");

    BaseWindow MainWindow;
    MainWindow.show();
    MainWindow.setAttribute(Qt::WA_QuitOnClose);

    return app.exec();
}


