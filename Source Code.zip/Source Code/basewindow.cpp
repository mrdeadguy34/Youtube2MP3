#include "basewindow.h"
#include "datalabel.h"
#include "json.hpp"
#include "picosha2.h"
#include <QtCore>
#include <QtWidgets>
#include <QApplication>
#include <cstdlib>
#include <fstream>
#include <string>
#include <Windows.h>

//test = https://www.youtube.com/watch?v=nH1lNaJpud4

using json = nlohmann::json;

Downloads::Downloads(QVector<DataWidget*> Files, std::string Directory)
{
    DLFiles = Files;
    directory = Directory;
}

void Downloads::DownloadFiles()
{
    //Loops through each element in the vector executing the download command
    int index = 0;
    while (index < DLFiles.count()){
        DataLabel* FileData = DLFiles[index]->VidData;
        std::string OUTFILE = "-o \""+directory+"/Downloads/"+FileData->Title.toStdString()+"/"+FileData->Title.toStdString()+".%(ext)s\"";
        qDebug() << QString::fromStdString(OUTFILE);
        std::string DLCommand = "youtube-dl --extract-audio --audio-format mp3 "+OUTFILE+" "+FileData->Url.toStdString();
        qDebug() << QString::fromStdString(DLCommand);
        execCmd(DLCommand.c_str());
        index++;
    }
    emit finished();
}

BaseWindow::BaseWindow(QWidget *parent)
    : QWidget(parent)
{
    //Main window set up
    setWindowTitle(QString("Youtube2MP3"));
    SetSize(this,730,390);
    setStyleSheet("QWidget {background-color: rgb(230, 230, 240);}");
    CreateActions();
    LoadWidgets();
}

void BaseWindow::CleanUpAll()
{
    //Function to remove all elements from the vector and hide them
    while (!(DataWidgets.isEmpty())){
        DataWidgets[0]->hide();
        DataWidgets.remove(0);
    }
}

void BaseWindow::DownloadMP3()
{
    Downloads* AllFiles = new Downloads(DataWidgets, Directory.toStdString());
    QThread* DLThread = new QThread();
    AllFiles->moveToThread(DLThread);
    connect(AllFiles, &Downloads::finished, this, &BaseWindow::CleanUpAll);
    DLThread->start();
    AllFiles->DownloadFiles();
    //process will hang dialog here
}

void BaseWindow::DeleteData(QString Id)
{
    //Loops through to find a matching ID then hiding it and deleting it from the Vector
    int index = 0;
    while (index < DataWidgets.count()){
        if (DataWidgets[index]->VidData->ID == Id){
            DataWidgets[index]->hide();
            DataWidgets.remove(index);
            if (DataWidgets.count() == 0){
                break;
            }
            else {
                if (index < DataWidgets.count()){
                    DataWidgets[index]->show();
                    break;
                }
                else {
                    DataWidgets[0]->show();
                    break;
                }
            }
        }
        else {
            index++;
        }
    }
}

void BaseWindow::ShowNext(QString ID)
{
    //Loops through for am atching ID then shows the widget
    int index = 0;
    while (index < DataWidgets.count()){
        if (DataWidgets[index]->VidData->ID == ID){
            qDebug() << index;
            if (DataWidgets.count() == 0){
                break;
            }
            else {
            }
            DataWidgets[index]->hide();
            if (index == DataWidgets.count() -1){
                qDebug() << "load 0";
                DataWidgets[0]->show();
                break;
            }
            else {
                qDebug() << "load +1";
                DataWidgets[index+1]->show();
                break;
            }
        }
        else {
            index++;
        }
    }
}

void BaseWindow::createNewData(std::string hashString)
{
    //Create the data for a new datalabel
    if (!dirExists(Directory.toStdString()+"/Bin/Data/"+hashString)){ //check download
        return;
    }
    QString ID = QString::fromStdString(hashString); //ID is equal to the url hash so both python script and main window knows where it is stored
    QString Folder = QString(Directory+"/Bin/Data/"+ID); //Save folder directory
    std::fstream DataFile(QString(Directory+"/Bin/Data/"+ID+"/Info.json").toStdString());
    if (DataFile.fail()){
        qDebug() << "Failed to load" << strerror(errno);
        return;
    }
    qDebug() << "File Loaded";
    json Data;
    //Check if JSON can be parsed into data
    try{
        Data = json::parse(DataFile);
    } catch (json::parse_error &e){
        qDebug() << QString::fromLocal8Bit(e.what());
        return;
    }
    QString title = QString::fromStdString(Data["items"][0]["snippet"]["title"]);
    std::string ISOLength = Data["items"][0]["contentDetails"]["duration"];
    QString url = "https://youtu.be/"+QString::fromStdString(Data["items"][0]["id"]); //Remove extra tags from url to stop youtube-dl doing extra stuff
    if (QString::fromStdString(ISOLength).contains("H")){
        return;
        //create error message here. No videos over one hour
    }
    QString FormatLength = getLength(ISOLength); //Get formattted length from JSON
    QStringList MinsSecs = FormatLength.split(":");
    QString minutes = MinsSecs.value(0);
    QString secs = MinsSecs.value(1);
    int secsDuration = minutes.toInt() * 60 + secs.toInt(); //Get length of song from formatted length
    std::string smallPic = Data["items"][0]["snippet"]["thumbnails"]["default"]["url"]; //Urls for thumbnails downloaded via python script
    std::string highPic = Data["items"][0]["snippet"]["thumbnails"]["medium"]["url"];
    std::string cmdString = "python Bin/ThumbNailLoad.py " + smallPic + " " + highPic + " " + ID.toStdString(); //Exec command to download thumbnails
    execCmd(cmdString.c_str());
    QPixmap logoPix(Directory+"/Bin/Data/"+ID+"/smallThumbnail.jpg");
    QPixmap highPix(Directory+"/Bin/Data/"+ID+"/bigThumbnail.jpg");
    DataLabel* NewData = new DataLabel(logoPix, highPix, title, url, ID, Folder, FormatLength, secsDuration); //Create the new data
    DataWidget* NewWidget = new DataWidget(this,NewData);
    DataWidgets.append(NewWidget); //Add the new data to the storage
    connect(NewWidget, &DataWidget::DeleteThis, this, &BaseWindow::DeleteData);
    connect(NewWidget, &DataWidget::NextData, this, &BaseWindow::ShowNext);
    DataWidgets.last()->show();
}

void BaseWindow::SubmitUrl()
{
    //Submit and download url with the python script using youtube API
    QString Url = UrlInput->text();
    UrlBox->close();
    if (Url.isEmpty()){
        return;
    }
    std::string stringUrl = Url.toStdString();
    std::string hashString = picosha2::hash256_hex_string(stringUrl); //Hashed url for use as directory
    std::stringstream cmdStringStream;
    cmdStringStream << "python Bin/JSONLoad.py  \"" << stringUrl << "\"" << " \"" << hashString << "\"";
    std::string cmdString = cmdStringStream.str();
    const char* cmdCommand = cmdString.c_str();
    execCmd(cmdCommand); //Execute python download of JSON
    createNewData(hashString); //Turn JSON into datalabel
}

void BaseWindow::GetUrl()
{
    //User submits url
    UrlBox = new QDialog();
    UrlBox->setWindowFlags(Qt::WindowSystemMenuHint | Qt::WindowTitleHint | Qt::WindowCloseButtonHint);
    SetSize(UrlBox,550,150);
    UrlBox->setWindowTitle("Input url");
    UrlBox->setModal(true);
    UrlBox->setFont(QFont("Arial", 18));
    UrlBox->setStyleSheet("QDialog {background-color: rgb(230, 230, 240);}");
    QLabel *UrlLabel = new QLabel("Url: ", UrlBox);
    UrlLabel->setGeometry(0,10, 550, 20);
    UrlLabel->setAlignment(Qt::AlignCenter);
    UrlLabel->show();
    UrlInput = new QLineEdit(UrlBox);
    UrlInput->setGeometry(80,40, 390,25);
    UrlInput->setAlignment(Qt::AlignCenter);
    UrlInput->show();
    QPushButton *SubmitButton = new QPushButton("Submit", UrlBox);
    SubmitButton->setGeometry(220,75, 110,50);
    SubmitButton->setStyleSheet("QPushButton {"
                                "background-color: rgb(130, 130, 130);"
                                "color: rgb(200, 200, 200);}"
                                "QPushButton::pressed {"
                                "background-color: rgb(110, 110, 110);}");
    SubmitButton->show();
    connect(SubmitButton, &QPushButton::released, this, &BaseWindow::SubmitUrl);
    UrlBox->exec();
}

void BaseWindow::CreateActions()
{
    //Create actions for the menu bars
    InputUrl = new QAction(tr("&Import url"), this);
    InputUrl->setShortcut(QKeySequence::New);
    InputUrl->setToolTip("Import video from youtube url");
    DownloadAction = new QAction(tr("&Download files"), this);
    DownloadAction->setShortcut(QKeySequence::Save);
    DownloadAction->setToolTip("Download the inputted files");
    QuitAction = new QAction(tr("&Quit"), this);
    QuitAction->setShortcut(QKeySequence::Quit);
    QuitAction->setToolTip("Close the application");
    connect(InputUrl, &QAction::triggered, this, &BaseWindow::GetUrl);
    connect(DownloadAction, &QAction::triggered, this, &BaseWindow::DownloadMP3);
    connect(QuitAction, &QAction::triggered, this, &QApplication::quit);
}

void BaseWindow::LoadWidgets()
{
    //Load main widgets with stylesheets
    WindowMenu = new QMenuBar(this);
    MainMenu = new QMenu("&File");
    MainMenu->addAction(InputUrl);
    MainMenu->addSeparator();
    MainMenu->addAction(DownloadAction);
    MainMenu->addSeparator();
    MainMenu->addAction(QuitAction);
    WindowMenu->addMenu(MainMenu);
    WindowMenu->setFont(QFont("Arial", 12));
    WindowMenu->setStyleSheet("QMenuBar {"
                              "background-color: rgb(130, 130, 130);"
                              "color: rgb(200,200,200);}"
                              "QMenuBar::item {"
                              "background-color: rgb(130, 130, 130);"
                              "color: rgb(200, 200, 200);}"
                              "QMenuBar::item::selected {"
                              "background-color: rgb(90, 90, 90);}");
    MainMenu->setStyleSheet("QMenu {"
                            "background-color:rgb(130, 130, 130);"
                            "color: rgb(200,200,200);"
                            "border: 1px solid;}"
                            "QMenu::item::selected {"
                            "background-color: rgb(90, 90,90);}");
    WindowMenu->show();
}

BaseWindow::~BaseWindow()
{

}
